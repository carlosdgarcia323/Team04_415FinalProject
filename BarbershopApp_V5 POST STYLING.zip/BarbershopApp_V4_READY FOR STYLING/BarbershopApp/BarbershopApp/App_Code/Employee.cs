﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{
    public string empName { get; set; }
    public string empCity { get; set; }
    public string empStartDate { get; set; }
    public Employee()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}