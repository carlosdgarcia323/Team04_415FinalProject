﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Service
/// </summary>
public class Service
{
    public string ServiceName { get; set; }
    public string ServPrice { get; set; }
    public string ServDescription { get; set; }
    public int serviceID { get; set; }
    public Service()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}