﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customers
/// </summary>
public class Customer
{
    public string custFirstName { get; set; }
    public string custLastName { get; set; }
    public string custPhoneNumber { get; set; }
    public int CustomerID { get; set; }
    public Customer()
    {

        //
        // TODO: Add constructor logic here
        //
    }
}